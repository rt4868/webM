package com.samples.jservices;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-06-09 14:14:29 GMT+05:30
// -----( ON-HOST: TRAINER1

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class Test

{
	// ---( internal utility methods )---

	final static Test _instance = new Test();

	static Test _newInstance() { return new Test(); }

	static Test _cast(Object o) { return (Test)o; }

	// ---( server methods )---




	public static final void Sample_Concat (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(Sample_Concat)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		IDataCursor cursor1=pipeline.getCursor();
		String fname=IDataUtil.getString(cursor1,"FNAME");
		String lname=IDataUtil.getString(cursor1,"LNAME");
		cursor1.destroy();
		
		
		IDataCursor cursor2=pipeline.getCursor();
		IDataUtil.put(cursor2,"NAME","Mr "+fname+" "+lname);
		cursor2.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void sayHello (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sayHello)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required ID
		// [i] field:0:required NAME
		// [o] field:0:required HELLO_NAME
		IDataCursor cursor1=pipeline.getCursor();
		String id=IDataUtil.getString(cursor1,"ID");
		String name=IDataUtil.getString(cursor1,"NAME");
		cursor1.destroy();
		
		
		IDataCursor cursor2=pipeline.getCursor();
		IDataUtil.put(cursor2,"HELLO_NAME","Hello "+name);
		cursor2.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void sayHi (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sayHi)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required ID
		// [i] field:0:required NAME
		// [o] field:0:required HAI_NAME
		IDataCursor cursor1=pipeline.getCursor();
		String id=IDataUtil.getString(cursor1,"ID");
		String name=IDataUtil.getString(cursor1,"NAME");
		cursor1.destroy();
		
		
		IDataCursor cursor2=pipeline.getCursor();
		IDataUtil.put(cursor2,"HAI_NAME","Hai "+name);
		cursor2.destroy();
		// --- <<IS-END>> ---

                
	}
}


Location of classes for Java services.


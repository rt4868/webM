

// -----( IS Java Code Template v1.2
// -----( CREATED: 2006-06-11 11:03:55 GMT+05:30
// -----( ON-HOST: TRAINER1

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class jservices

{
	// ---( internal utility methods )---

	final static jservices _instance = new jservices();

	static jservices _newInstance() { return new jservices(); }

	static jservices _cast(Object o) { return (jservices)o; }

	// ---( server methods )---




	public static final void Sample (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(Sample)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}
}

